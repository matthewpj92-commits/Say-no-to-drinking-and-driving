import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type CreatePledgeInput } from "@shared/routes";

export function usePledges() {
  return useQuery({
    queryKey: [api.pledges.list.path],
    queryFn: async () => {
      const res = await fetch(api.pledges.list.path);
      if (!res.ok) throw new Error("Failed to fetch pledges");
      return api.pledges.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreatePledge() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreatePledgeInput) => {
      const res = await fetch(api.pledges.create.path, {
        method: api.pledges.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.pledges.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to submit pledge");
      }
      return api.pledges.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.pledges.list.path] });
    },
  });
}
