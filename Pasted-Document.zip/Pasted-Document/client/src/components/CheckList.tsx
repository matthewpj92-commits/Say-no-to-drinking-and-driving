import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface CheckItemProps {
  children: React.ReactNode;
  className?: string;
}

export function CheckItem({ children, className }: CheckItemProps) {
  return (
    <li className={cn("flex items-start space-x-3 group", className)}>
      <div className="flex-shrink-0 mt-1">
        <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
          <Check className="w-4 h-4 text-green-700" strokeWidth={3} />
        </div>
      </div>
      <span className="text-lg text-foreground/90 leading-relaxed pt-0.5">{children}</span>
    </li>
  );
}
