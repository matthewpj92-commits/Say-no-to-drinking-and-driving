import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatCardProps {
  value: string;
  label: string;
  description: string;
  icon?: React.ReactNode;
  className?: string;
}

export function StatCard({ value, label, description, icon, className }: StatCardProps) {
  return (
    <Card className={cn(
      "relative overflow-hidden p-6 hover:shadow-xl transition-all duration-300 border-none bg-white shadow-lg",
      className
    )}>
      <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none transform scale-150 text-primary">
        {icon}
      </div>
      <div className="relative z-10 flex flex-col h-full">
        <div className="text-4xl md:text-5xl font-black text-primary mb-2 tracking-tight">
          {value}
        </div>
        <div className="text-lg font-bold text-foreground mb-3 font-display uppercase tracking-wide opacity-80">
          {label}
        </div>
        <p className="text-muted-foreground leading-relaxed mt-auto">
          {description}
        </p>
      </div>
    </Card>
  );
}
