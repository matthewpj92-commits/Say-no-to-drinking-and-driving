## Packages
framer-motion | Smooth animations for section reveals and interactions
react-hook-form | Form state management
@hookform/resolvers | Zod validation for forms

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Montserrat", "sans-serif"],
}
