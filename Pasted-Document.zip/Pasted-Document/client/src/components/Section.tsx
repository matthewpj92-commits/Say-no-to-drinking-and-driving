import React from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface SectionProps {
  id?: string;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
  variant?: "default" | "alternate" | "danger" | "hero";
}

export function Section({ 
  id, 
  title, 
  subtitle, 
  children, 
  className,
  variant = "default" 
}: SectionProps) {
  const variants = {
    default: "bg-background",
    alternate: "bg-white",
    danger: "bg-destructive/5 border-y border-destructive/10",
    hero: "bg-primary text-primary-foreground py-24",
  };

  return (
    <section 
      id={id} 
      className={cn(
        "py-16 md:py-24 px-4 sm:px-6 lg:px-8 overflow-hidden",
        variants[variant],
        className
      )}
    >
      <div className="max-w-5xl mx-auto">
        {(title || subtitle) && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="mb-12 text-center"
          >
            {title && (
              <h2 className={cn(
                "text-3xl md:text-4xl lg:text-5xl mb-4 font-extrabold tracking-tight",
                variant === "hero" ? "text-white" : "text-primary",
                variant === "danger" && "text-destructive"
              )}>
                {title}
              </h2>
            )}
            {subtitle && (
              <p className={cn(
                "text-lg md:text-xl max-w-2xl mx-auto leading-relaxed",
                variant === "hero" ? "text-primary-foreground/90" : "text-muted-foreground"
              )}>
                {subtitle}
              </p>
            )}
            {variant !== "hero" && (
              <div className={cn(
                "h-1 w-20 mx-auto mt-6 rounded-full",
                variant === "danger" ? "bg-destructive/30" : "bg-primary/20"
              )} />
            )}
          </motion.div>
        )}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {children}
        </motion.div>
      </div>
    </section>
  );
}
