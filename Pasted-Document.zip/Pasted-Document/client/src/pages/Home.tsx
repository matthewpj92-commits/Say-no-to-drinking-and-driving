import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPledgeSchema } from "@shared/schema";
import { usePledges, useCreatePledge } from "@/hooks/use-pledges";
import { Section } from "@/components/Section";
import { StatCard } from "@/components/StatCard";
import { CheckItem } from "@/components/CheckList";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { 
  ShieldCheck, 
  AlertTriangle, 
  Car, 
  Beer, 
  Smartphone, 
  HeartHandshake, 
  User,
  ArrowRight
} from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: pledges } = usePledges();
  const createPledge = useCreatePledge();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(insertPledgeSchema),
    defaultValues: {
      name: "",
      message: "",
    },
  });

  const onSubmit = (data: any) => {
    createPledge.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Pledge Signed!",
          description: "Thank you for committing to safe driving.",
        });
        form.reset();
      },
      onError: (error) => {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  };

  const scrollToPledge = () => {
    document.getElementById("pledge")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-primary">
        {/* Abstract Background Shapes */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-[20%] -right-[10%] w-[70vw] h-[70vw] bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-[20%] -left-[10%] w-[70vw] h-[70vw] bg-indigo-500/10 rounded-full blur-3xl" />
        </div>

        <div className="container relative z-10 px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center justify-center p-2 mb-8 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 text-white/90 shadow-lg">
              <span className="bg-primary px-3 py-1 rounded-full text-xs font-bold mr-2 uppercase tracking-wider">Campaign</span>
              <span className="text-sm font-medium pr-2">2025 Safety Initiative</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white mb-6 tracking-tight leading-[1.1]">
              Drive Smart. <br className="hidden md:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 to-indigo-200">
                Live Safe.
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto mb-10 leading-relaxed font-light">
              Your choices behind the wheel impact everyone. Join us in making the roads safer for our community, our friends, and our families.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button 
                onClick={scrollToPledge}
                size="lg" 
                className="w-full sm:w-auto text-lg h-14 px-8 rounded-full bg-white text-primary hover:bg-blue-50 font-bold shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all duration-300"
              >
                Take the Pledge <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="w-full sm:w-auto text-lg h-14 px-8 rounded-full border-white/30 text-white hover:bg-white/10 backdrop-blur-sm font-medium"
                onClick={() => document.getElementById("stats")?.scrollIntoView({ behavior: "smooth" })}
              >
                Learn the Facts
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Underage Drinking Section */}
      <Section 
        id="underage" 
        variant="alternate"
        title="Underage Drinking"
        subtitle="It's illegal, dangerous, and can change your life in an instant."
      >
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="prose prose-lg text-muted-foreground">
            <p className="mb-6">
              Alcohol interferes with the brain’s development, specifically affecting areas responsible for learning and memory. For young people, the consequences of drinking extend far beyond a hangover.
            </p>
            <ul className="space-y-4 not-prose">
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold">1</div>
                <span>Impaired judgment leading to risky behaviors</span>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold">2</div>
                <span>Increased risk of physical and sexual assault</span>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold">3</div>
                <span>Interference with brain development</span>
              </li>
            </ul>
          </div>
          <div className="bg-primary/5 rounded-3xl p-8 relative overflow-hidden">
            <Beer className="absolute -bottom-10 -right-10 w-64 h-64 text-primary/10" />
            <h3 className="text-2xl font-bold mb-4 relative z-10">Did you know?</h3>
            <p className="text-lg mb-6 relative z-10">
              People who start drinking before age 15 are <strong>4 times more likely</strong> to develop alcohol dependence later in life compared to those who wait until they are 21.
            </p>
            <div className="bg-white p-6 rounded-xl shadow-sm relative z-10 border border-primary/10">
              <span className="block text-sm font-semibold text-primary uppercase tracking-wider mb-2">Legal Consequence</span>
              <p className="font-medium">Zero Tolerance Laws mean any detectable amount of alcohol in drivers under 21 is a DUI offense.</p>
            </div>
          </div>
        </div>
      </Section>

      {/* Danger Section */}
      <Section 
        id="danger" 
        variant="danger"
        title="Why It's Dangerous"
        subtitle="Drinking and driving isn't just a mistake—it's a deadly choice."
      >
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-none shadow-lg bg-white/50 backdrop-blur-sm hover:bg-white transition-colors duration-300">
            <CardHeader>
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle className="text-xl">Reduced Coordination</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Alcohol affects your fine motor skills and hand-eye coordination, making it impossible to steer effectively or brake in time.
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-white/50 backdrop-blur-sm hover:bg-white transition-colors duration-300">
            <CardHeader>
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Smartphone className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle className="text-xl">Slowed Reaction Time</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                When you drink, you can't respond quickly to unexpected situations like a car stopping in front of you or a pedestrian crossing.
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-white/50 backdrop-blur-sm hover:bg-white transition-colors duration-300">
            <CardHeader>
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Car className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle className="text-xl">Impaired Vision</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Alcohol can blur your vision and cause difficulty judging distance and speed, crucial factors for safe driving.
              </p>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Statistics Section */}
      <Section 
        id="stats" 
        variant="default"
        title="The Hard Facts"
        subtitle="Statistics represent real lives lost. Don't become a statistic."
      >
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard 
            value="31%" 
            label="Of Fatalities" 
            description="Nearly one-third of all traffic crash fatalities in the US involve drunk drivers."
            icon={<AlertTriangle />}
          />
          <StatCard 
            value="10,000+" 
            label="Lives Lost" 
            description="Every year, over 10,000 people die in alcohol-impaired driving crashes."
            icon={<User />}
          />
          <StatCard 
            value="$44B" 
            label="Annual Cost" 
            description="The annual cost of alcohol-related crashes totals more than $44 billion."
            icon={<Car />}
          />
          <StatCard 
            value="Every 50m" 
            label="Frequency" 
            description="One person is killed in a drunk-driving crash every 50 minutes in the US."
            icon={<ShieldCheck />}
          />
        </div>
      </Section>

      {/* Distracted Driving */}
      <Section 
        id="distracted" 
        variant="alternate"
        title="Distracted Driving"
        subtitle="It's not just alcohol. Texting while driving is 6x more likely to cause an accident than driving drunk."
      >
        <div className="bg-background rounded-3xl p-8 md:p-12 shadow-inner">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h3 className="text-2xl font-bold mb-6">Visual, Manual, Cognitive</h3>
              <p className="text-muted-foreground mb-6 text-lg">
                Distracted driving takes your eyes off the road, your hands off the wheel, and your mind off of driving. Texting involves all three.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-4 bg-white p-4 rounded-xl shadow-sm">
                  <span className="font-bold text-3xl text-primary w-16 text-center">5s</span>
                  <p className="text-sm text-muted-foreground">The average time your eyes are off the road while texting. At 55mph, that's like driving the length of a football field blindfolded.</p>
                </div>
              </div>
            </div>
            <div className="order-1 md:order-2 flex justify-center">
              <div className="relative w-64 h-80 bg-gray-900 rounded-[3rem] border-8 border-gray-800 shadow-2xl flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-black opacity-50" />
                <div className="relative z-10 text-center p-6">
                  <div className="w-16 h-16 bg-red-500 rounded-full mx-auto mb-4 flex items-center justify-center animate-pulse">
                    <span className="text-2xl font-bold text-white">!</span>
                  </div>
                  <p className="text-white font-medium">Message</p>
                  <p className="text-gray-400 text-sm mt-2">Can you talk?</p>
                  <p className="text-red-400 font-bold mt-8 uppercase tracking-widest text-xs">Don't Reply</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* Safer Choices */}
      <Section 
        id="safer" 
        variant="default"
        title="Make Safer Choices"
        subtitle="Planning ahead saves lives. Here is what you can do."
      >
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="shadow-lg border-l-4 border-l-green-500 hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle>Before You Go Out</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                <CheckItem>Designate a non-drinking driver before any celebration begins.</CheckItem>
                <CheckItem>Save the numbers of local cab companies or rideshare apps in your phone.</CheckItem>
                <CheckItem>Leave your keys at home if you plan to drink.</CheckItem>
              </ul>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-l-4 border-l-blue-500 hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle>During & After</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                <CheckItem>Never let a friend drive drunk. Take their keys.</CheckItem>
                <CheckItem>If you've been drinking, call a cab, a friend, or family member.</CheckItem>
                <CheckItem>If you see a drunk driver on the road, contact law enforcement immediately.</CheckItem>
              </ul>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Pledge Section */}
      <Section 
        id="pledge" 
        variant="hero"
        className="bg-primary text-white"
        title="Take The Pledge"
        subtitle="Join your community in committing to safe driving habits. Your promise matters."
      >
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-8 shadow-2xl text-foreground">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="text-center mb-8">
              <HeartHandshake className="w-16 h-16 text-primary mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-primary">I Pledge To...</h3>
              <p className="text-muted-foreground mt-2">
                Drive sober, stay focused, and help others make safe choices.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 ml-1 text-muted-foreground">Your Name</label>
                <Input 
                  placeholder="Enter your full name" 
                  {...form.register("name")}
                  className="h-12 px-4 rounded-xl bg-gray-50 border-gray-200 focus:ring-primary focus:border-primary transition-all"
                />
                {form.formState.errors.name && (
                  <p className="text-red-500 text-sm mt-1 ml-1">{form.formState.errors.name.message}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 ml-1 text-muted-foreground">Why I Pledge (Optional)</label>
                <Textarea 
                  placeholder="I pledge for my family..." 
                  {...form.register("message")}
                  className="rounded-xl bg-gray-50 border-gray-200 focus:ring-primary focus:border-primary transition-all resize-none min-h-[100px]"
                />
              </div>

              <Button 
                type="submit" 
                disabled={createPledge.isPending}
                className="w-full h-14 text-lg rounded-xl bg-primary hover:bg-primary/90 text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200"
              >
                {createPledge.isPending ? "Signing Pledge..." : "Sign the Pledge"}
              </Button>
            </div>
          </form>

          {/* Recent Pledges */}
          <div className="mt-12">
            <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-widest mb-6 text-center">Recent Pledges</h4>
            <div className="space-y-3 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
              {pledges?.map((pledge) => (
                <motion.div 
                  key={pledge.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-gray-50 p-4 rounded-xl flex items-start gap-3"
                >
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 text-primary font-bold text-xs">
                    {pledge.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-bold text-sm text-primary">{pledge.name}</p>
                    {pledge.message && (
                      <p className="text-xs text-muted-foreground mt-1">"{pledge.message}"</p>
                    )}
                    <p className="text-[10px] text-muted-foreground/60 mt-2">
                      {new Date(pledge.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </motion.div>
              ))}
              {(!pledges || pledges.length === 0) && (
                <p className="text-center text-muted-foreground text-sm italic">Be the first to pledge!</p>
              )}
            </div>
          </div>
        </div>
      </Section>

      {/* About Me Section */}
      <Section id="about" variant="alternate" className="py-12">
        <div className="max-w-3xl mx-auto text-center">
          <h3 className="text-2xl font-bold mb-4">About the Campaign</h3>
          <p className="text-lg text-muted-foreground leading-relaxed">
            This initiative was created by <span className="font-bold text-primary">Matthew Johnson</span> to raise awareness about the critical importance of safe driving habits in our community. Together, we can save lives.
          </p>
          <div className="mt-8 pt-8 border-t">
            <p className="text-sm text-muted-foreground">© 2025 Drive Smart. Live Safe. Campaign</p>
          </div>
        </div>
      </Section>
    </div>
  );
}
