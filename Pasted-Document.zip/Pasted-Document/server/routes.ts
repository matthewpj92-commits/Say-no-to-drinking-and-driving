import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Pledges API
  app.get(api.pledges.list.path, async (req, res) => {
    const pledges = await storage.getPledges();
    res.json(pledges);
  });

  app.post(api.pledges.create.path, async (req, res) => {
    try {
      const input = api.pledges.create.input.parse(req.body);
      const pledge = await storage.createPledge(input);
      res.status(201).json(pledge);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      } else {
        throw err;
      }
    }
  });

  // Seed initial pledges if none exist
  const existingPledges = await storage.getPledges();
  if (existingPledges.length === 0) {
    await storage.createPledge({
      name: "Matthew Johnson",
      message: "I pledge to drive safely and encourage others to do the same. Awareness is the first step.",
    });
    await storage.createPledge({
      name: "Sarah Williams",
      message: "For my friends and family, I promise to never drink and drive.",
    });
    await storage.createPledge({
      name: "David Chen",
      message: "Distracted driving is not worth the risk. Eyes on the road!",
    });
    console.log("Seeded initial pledges");
  }

  return httpServer;
}
