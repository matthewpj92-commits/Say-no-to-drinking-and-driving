import { pledges, type InsertPledge, type Pledge } from "@shared/schema";
import { db } from "./db";
import { desc } from "drizzle-orm";

export interface IStorage {
  getPledges(): Promise<Pledge[]>;
  createPledge(pledge: InsertPledge): Promise<Pledge>;
}

export class DatabaseStorage implements IStorage {
  async getPledges(): Promise<Pledge[]> {
    return await db.select().from(pledges).orderBy(desc(pledges.createdAt));
  }

  async createPledge(insertPledge: InsertPledge): Promise<Pledge> {
    const [pledge] = await db
      .insert(pledges)
      .values(insertPledge)
      .returning();
    return pledge;
  }
}

export const storage = new DatabaseStorage();
