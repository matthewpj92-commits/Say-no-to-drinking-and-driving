import { pgTable, text, serial, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const pledges = pgTable("pledges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  message: text("message"), // Optional personal commitment
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPledgeSchema = createInsertSchema(pledges).pick({
  name: true,
  message: true,
});

export type Pledge = typeof pledges.$inferSelect;
export type InsertPledge = z.infer<typeof insertPledgeSchema>;

export type CreatePledgeRequest = InsertPledge;
export type PledgeResponse = Pledge;
